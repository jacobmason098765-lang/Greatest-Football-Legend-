# The Ultimate Football Legend — starter project

This project adds the missing stylesheet, frontend logic, and a Node.js API that checks payment transactions on BNB Smart Chain before crediting votes.

## Important before collecting real money

This is a functional starter implementation, not a security audit or a guarantee of production readiness. Verify token contracts and wallet ownership independently, test with small transfers, add monitoring/backups/rate limits, and have a qualified developer review it before public launch. Stablecoins can depeg; `$1 per vote` here means 1 token unit per vote, not a guaranteed market value of exactly USD $1. The server never asks for or stores wallet private keys.

## What it does

- Serves `public/index.html`, `public/styles.css`, and `public/app.js`.
- Creates an order for one of five players, 1–10,000 votes, paid in USDT or USDC.
- Verifies the submitted transaction hash against the configured BSC chain, token contract, recipient, exact amount, successful receipt, and confirmation threshold.
- Prevents a confirmed transaction hash from being credited to another order.
- Persists orders and calculates leaderboard counts from confirmed orders only.

The user must send the payment from their wallet themselves, then submit the transaction hash. QR codes and automatic wallet payment are not included in this starter.

## Requirements

- Node.js 20 or newer
- Internet access to a BNB Smart Chain RPC endpoint

## Run locally

1. Extract this ZIP.
2. Open a terminal in the extracted `football-legend-site` folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env` and review every value. The default recipient is the address supplied for this project.
5. Run `npm start`.
6. Open `http://localhost:3000` in your browser.

On Android, a terminal app such as Termux can run Node.js, but a hosted Node.js service is usually easier for a public site. Do not upload `.env` or `data/db.json` to a public repository.

## Payment flow

1. User creates an order in the website.
2. The site shows the recipient, token, and exact amount.
3. User sends that exact amount of the selected token on BNB Smart Chain.
4. User pastes the transaction hash into the site.
5. The server checks the transaction receipt and matching ERC-20 Transfer logs. The vote count changes only after the required confirmations.

## Before production launch

- Verify USDT/USDC contract addresses and decimals from trustworthy sources and the token issuer/explorer. The configured BSC token contracts may be bridged/pegged assets rather than issuer-native assets.
- Use a managed RPC provider with suitable rate limits and monitoring; set `BSC_RPC_URL`.
- Use durable database storage (PostgreSQL or similar) rather than the JSON file for a public, multi-instance deployment.
- Add rate limiting, request logging, backups, uptime alerts, and abuse controls.
- Consider a unique per-order payment reference or payment contract to avoid ambiguity when several identical orders are paid to the same address. This starter verifies exact amount and prevents reusing a credited hash, but identical payments cannot be safely matched automatically without a unique reference.
- Review consumer protection, privacy, tax, and local legal requirements for paid voting.

## API endpoints

- `GET /api/health` — checks RPC chain identity.
- `GET /api/leaderboard` — verified vote totals only.
- `POST /api/orders` — JSON `{ "playerId": "messi", "quantity": 1, "currency": "USDT" }`.
- `POST /api/orders/:id/verify` — JSON `{ "txHash": "0x..." }`.
